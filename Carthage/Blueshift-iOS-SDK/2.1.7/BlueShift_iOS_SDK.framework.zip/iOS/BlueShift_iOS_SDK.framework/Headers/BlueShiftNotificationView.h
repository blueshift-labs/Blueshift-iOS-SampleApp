//
//  BlueShiftNotificationView.h
//  BlueShift-iOS-Extension-SDK
//
//  Created by shahas kp on 12/07/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BlueShiftNotificationView : UIView

@end

NS_ASSUME_NONNULL_END
